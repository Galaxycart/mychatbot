from flask import Flask, request, render_template_string, send_from_directory, render_template
import docx
import os
from docx.opc.constants import RELATIONSHIP_TYPE

app = Flask(__name__)

# Function to save images from the document
def save_images(doc, output_dir):
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    
    image_files = {}
    for rel in doc.part.rels.values():
        if "image" in rel.target_ref:
            image_part = rel.target_part
            image_name = os.path.basename(rel.target_ref)
            image_path = os.path.join(output_dir, image_name)
            with open(image_path, 'wb') as img_file:
                img_file.write(image_part.blob)
            image_files[rel.rId] = image_path
    return image_files

# Function to convert relevant document content to HTML
def docx_to_html(doc, images, keyword):
    html_sections = []
    keyword_found = False
    paragraph_buffer = []
    
    for para in doc.paragraphs:
        elements = []

        for run in para.runs:
            run_text = run.text
            if run.bold:
                run_text = f'<b>{run_text}</b>'
            if run.italic:
                run_text = f'<i>{run_text}</i>'
            if run.underline:
                run_text = f'<u>{run_text}</u>'
            elements.append(run_text)
        
        # Check for images within the runs and insert them in the correct location
        for run in para.runs:
            if run.element.tag.endswith('r'):
                for child in run.element:
                    if child.tag.endswith('drawing') or child.tag.endswith('pict'):
                        for rel in doc.part.rels.values():
                            if "image" in rel.target_ref and rel.rId in run.element.xml:
                                elements.append(f'<img src="/static/images/{os.path.basename(images[rel.rId])}" alt="Image" />')

        text = "".join(elements).strip()
        
        # Check if the paragraph contains the keyword
        if keyword.lower() in text.lower():
            keyword_found = True
        
        # Store the paragraph in a buffer
        paragraph_buffer.append((para.style.name, text))
        
        # Keep only the last few paragraphs for context
        if len(paragraph_buffer) > 5:
            paragraph_buffer.pop(0)

        if keyword_found:
            # Include a few preceding and following paragraphs for context
            for style, content in paragraph_buffer:
                if not content:
                    continue

                if 'Heading 1' in style:
                    html_sections.append(f'<h1>{content}</h1>')
                elif 'Heading 2' in style:
                    html_sections.append(f'<h2>{content}</h2>')
                elif 'Heading 3' in style:
                    html_sections.append(f'<h3>{content}</h3>')
                else:
                    html_sections.append(f'<p>{content}</p>')

            keyword_found = False
            paragraph_buffer = []

    return '\n'.join(html_sections)

# Function to search for a keyword in all .docx files in a directory
def search_keyword_in_directory(directory, keyword, output_dir):
    html_results = []
    
    for filename in os.listdir(directory):
        if filename.endswith('.docx'):
            filepath = os.path.join(directory, filename)
            doc = docx.Document(filepath)
            
            # Save images from the document
            images = save_images(doc, output_dir)
            
            # Convert the document content to HTML
            html_content = docx_to_html(doc, images, keyword)
            
            if html_content:
                html_results.append(f"<h1>{filename}</h1>")
                html_results.append(html_content)
    
    # Combine all HTML results into one string
    return '\n'.join(html_results)

@app.route('/', methods=['GET', 'POST'])
def index():
        return render_template('index_w1.html')

@app.route('/search', methods=['POST'])

def search():
    html_output = ""
    if request.method == 'POST':
        keyword = request.form['keyword']
        directory = 'documents'
        image_dir = 'static/images'
        
        # Search for the keyword and convert related sections to HTML
        html_output = search_keyword_in_directory(directory, keyword, image_dir)
    return render_template('results_w3.html', keyword=keyword, output=html_output)
    # return render_template_string('''
    #     <!doctype html>
    #     <html lang="en">
    #     <head>
    #         <meta charset="UTF-8">
    #         <meta name="viewport" content="width=device-width, initial-scale=1.0">
    #         <title>Keyword Search in Documents</title>
    #     </head>
    #     <body>
    #         <h1>Keyword Search in Documents</h1>
    #         <form method="post">
    #             <label for="keyword">Keyword:</label>
    #             <input type="text" id="keyword" name="keyword" required>
    #             <button type="submit">Search</button>
    #         </form>
    #         <div>
    #             {{ html_output|safe }}
    #         </div>
    #     </body>
    #     </html>
    # ''', html_output=html_output)

@app.route('/static/<path:filename>')
def send_static(filename):
    return send_from_directory('static', filename)

if __name__ == '__main__':
    # Ensure the static directory exists
    if not os.path.exists('static/images'):
        os.makedirs('static/images')
    app.run(debug=True)
