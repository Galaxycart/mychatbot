from flask import Flask, request, render_template, jsonify
#from your_module import search_keyword_in_documents  # Import your search function
import os
import nltk
import pdfplumber
import docx
from docx import Document
from nltk.tokenize import sent_tokenize
from PyPDF2 import PdfFileReader
import spacy
from nltk.tokenize import BlanklineTokenizer
from jinja2 import Template
import re

app = Flask(__name__)
nltk.download('punkt')

# def extract_text_from_pdf(pdf_path):
#     text = ""
#     with pdfplumber.open(pdf_path) as pdf:
#         for page in pdf.pages:
#             text += page.extract_text()
#     return text

def extract_text_from_docx(file_path):
    doc = docx.Document(file_path)
    ## text = "\n".join([para.text for para in doc.paragraphs])
    # text = ([para.text for para in doc.paragraphs])
    ## return text
    full_text = []
    for para in doc.paragraphs:
        full_text.append(para.text)
    return '\n'.join(full_text)

##########################################
def parse_paragraphs(paragraphs):
    parsed_html = []
    for para in paragraphs:
        # Handle headings and subheadings
        if para.style.name.startswith('Heading'):
            level = int(para.style.name.split()[-1])
            tag = f'h{level}'
            parsed_html.append(f'<{tag}>{para.text}</{tag}>')
        # Handle bullet points
        elif para.style.name == 'List Bullet':
            parsed_html.append(f'<li><h2>{para.text}</h2></li>')
        # Handle numbered headings
        elif para.style.name == 'List Number':
            parsed_html.append(f'<h2><li>{para.text}</li><h2>')
        # Handle paragraphs
        else:
            parsed_html.append(f'<p>{para.text}</p>')
    return '\n'.join(parsed_html)
##########################################

# def extract_text_from_txt(txt_path):
#     with open(txt_path, 'r') as file:
#         text = file.read()
#     return text

# def search_files(keyword):
#     results = []
#     for filename in os.listdir(directory):
#         if filename.endswith('.docx'):
#             file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
#             text = read_docx(file_path)
#             if keyword in text:
#                 results.append({
#                     'filename': filename,
#                     'content': text
#                 })
#     return results


# def extract_text_from_file(file_path):
#     # if file_path.endswith('.pdf'):
#     #     return extract_text_from_pdf(file_path)
#     if file_path.endswith('.docx'):
#         return extract_text_from_docx(file_path)
#     # elif file_path.endswith('.txt'):
#     #     return extract_text_from_txt(file_path)
#     else:
#         raise ValueError(f"Unsupported file type: {file_path}")


def search_keyword_in_documents(keyword, directory):
    results = []
    for filename in os.listdir(directory):
        if filename.endswith('.docx'):
            file_path = os.path.join(directory, filename)
            text = extract_text_from_docx(file_path)
            # if keyword in text:
            if keyword.lower() in text.lower():
                # results[filename] = text
                results.append({
                    'filename': filename,
                    'content': text
                })
    return results
    # try:
    #         text = extract_text_from_file(file_path)
    #         # relevant_sections = search_keyword_in_text(keyword, text)
    #         relevant_sections = extract_text_from_docx(keyword, text)
    #         if relevant_sections:
    #             results[filename] = relevant_sections
    # except Exception as e:
    #         print(f"Error processing {filename}: {e}")
    # return results
# sections = results['content']

 
def generate_html(html_content):
    html_template = """
    <!DOCTYPE html>
    <html>
    <head>
        <title>System Performance Utilization</title>
        <style>
            body {{
                font-family: Arial, sans-serif;
                margin: 20px;
            }}
            h1, h2 {{
                color: #2c3e50;
            }}
            pre {{
                background-color: #f4f4f4;
                padding: 10px;
                border: 1px solid #ddd;
                border-radius: 5px;
            }}
            code {{
                background-color: #eef;
                padding: 2px 4px;
                border-radius: 3px;
            }}
        </style>
    </head>
    <body>
        {}
    </body>
    </html>
    """        
    return html_template.format(html_content)


@app.route('/')
def index():
    return render_template('index_w1.html')

@app.route('/search', methods=['POST'])

def search():
    directory = 'documents'
    keyword = request.form['keyword'].lower().strip()
    if keyword.lower() == 'exit':
       return "Goodbye!"
            
    results = search_keyword_in_documents(keyword, directory)
    if results:
        html_content = ''
        for result in results:
            sections = result['content'].split('\n')
            html_sections = []
            for section in sections:
                lines = section.split('\n')
                if lines[0].startswith('---'):
                    html_sections.append(f'<h1>{lines[0]}</h1>')
                    html_sections.append(f'<h2>{lines[1]}</h2>')
                else:
                    for line in lines:
                        if line.startswith('1.') or line.startswith('2.'):
                            html_sections.append(f'<h2>{line}</h2>')
                        elif line.startswith('bash'):
                            continue
                        elif line.startswith('Copy code'):
                            continue
                        elif line:
                            html_sections.append(f'<p>{line}</p>')
                        else:
                            html_sections.append('<pre><code></code></pre>')
            html_content += '\n'.join(html_sections)
            # print('html_content')

            html_output = generate_html(html_content)
            return render_template('results_w3.html', keyword=keyword, output=html_content)
        # return render_template('results_w1.html', keyword=keyword, output=html_output)
    
    else:
        return "No relevant sections found."

if __name__ == "__main__":
    app.run(debug=True, host='127.0.0.1', port=8082)

    # if results:
    #     html_content =''
    #     sections = results['content']
    #     html_sections = []
    #     for section in sections:
    #         lines = section.split('\n')
    #         if lines[0].startswith('---'):
    #             html_sections.append(f'<h1>{lines[0]}</h1>')
    #             html_sections.append(f'<h2>{lines[1]}</h2>')
    #         else:
    #             for line in lines:
    #                 if line.startswith('1.') or line.startswith('2.'):
    #                     html_sections.append(f'<h2>{line}</h2>')
    #                 elif line.startswith('bash'):
    #                     continue
    #                 elif line.startswith('Copy code'):
    #                     continue
    #                 elif line:
    #                     html_sections.append(f'<p>{line}</p>')
    #                 else:
    #                     html_sections.append('<pre><code></code></pre>')
    #             html_content += '\n'.join(html_sections)

