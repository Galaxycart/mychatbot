from flask import Flask, request, render_template, jsonify
#from your_module import search_keyword_in_documents  # Import your search function
import os
import nltk
import pdfplumber
import docx
from docx import Document
from nltk.tokenize import sent_tokenize
from PyPDF2 import PdfFileReader
import spacy
from nltk.tokenize import BlanklineTokenizer
from jinja2 import Template
import re

app = Flask(__name__)
nltk.download('punkt')

# def extract_text_from_pdf(pdf_path):
#     text = ""
#     with pdfplumber.open(pdf_path) as pdf:
#         for page in pdf.pages:
#             text += page.extract_text()
#     return text

def extract_text_from_docx(file_path):
    doc = docx.Document(file_path)
    ## text = "\n".join([para.text for para in doc.paragraphs])
    # text = ([para.text for para in doc.paragraphs])
    ## return text
    full_text = []
    for para in doc.paragraphs:
        full_text.append(para.text)
    return '\n'.join(full_text)

##########################################
def parse_paragraphs(paragraphs):
    parsed_html = []
    for para in paragraphs:
        # Handle headings and subheadings
        if para.style.name.startswith('Heading'):
            level = int(para.style.name.split()[-1])
            tag = f'h{level}'
            parsed_html.append(f'<{tag}>{para.text}</{tag}>')
        # Handle bullet points
        elif para.style.name == 'List Bullet':
            parsed_html.append(f'<li>{para.text}</li>')
        # Handle numbered headings
        elif para.style.name == 'List Number':
            parsed_html.append(f'<li>{para.text}</li>')
        # Handle paragraphs
        else:
            parsed_html.append(f'<p>{para.text}</p>')
    return '\n'.join(parsed_html)
##########################################

# def extract_text_from_txt(txt_path):
#     with open(txt_path, 'r') as file:
#         text = file.read()
#     return text

# def search_files(keyword):
#     results = []
#     for filename in os.listdir(directory):
#         if filename.endswith('.docx'):
#             file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
#             text = read_docx(file_path)
#             if keyword in text:
#                 results.append({
#                     'filename': filename,
#                     'content': text
#                 })
#     return results


# def extract_text_from_file(file_path):
#     # if file_path.endswith('.pdf'):
#     #     return extract_text_from_pdf(file_path)
#     if file_path.endswith('.docx'):
#         return extract_text_from_docx(file_path)
#     # elif file_path.endswith('.txt'):
#     #     return extract_text_from_txt(file_path)
#     else:
#         raise ValueError(f"Unsupported file type: {file_path}")


def search_keyword_in_documents(keyword, directory):
    results = []
    for filename in os.listdir(directory):
        if filename.endswith('.docx'):
            file_path = os.path.join(directory, filename)
            text = extract_text_from_docx(file_path)
            # if keyword in text:
            if keyword.lower() in text.lower():
                # results[filename] = text
                results.append({
                    'filename': filename,
                    'content': text
                })
    return results
    #     try:
    #         text = extract_text_from_file(file_path)
    #         # relevant_sections = search_keyword_in_text(keyword, text)
    #         relevant_sections = extract_text_from_docx(keyword, text)
    #         if relevant_sections:
    #             results[filename] = relevant_sections
    #     except Exception as e:
    #         print(f"Error processing {filename}: {e}")
    # return results

@app.route('/')
def index():
    return render_template('index_w1.html')

@app.route('/search', methods=['POST'])

def search():
    directory = 'documents'

    while True:
     keyword = request.form['keyword'].lower().strip()

     if keyword.lower() == 'exit':
        return "Goodbye!"
         
     results = search_keyword_in_documents(keyword, directory)
  
     if results:
            results_html = []
            for result in results:
                # file_path = os.path.join(directory, result['filename'])
                filename = result['filename']
                # content = result['content']
                file_path = os.path.join(directory, filename)
                doc = docx.Document(file_path )
                parsed_html = parse_paragraphs(doc.paragraphs)
                results_html.append({
                'filename': filename,
                'parsed_html': parsed_html
                })
            return render_template('results_w1.html', keyword=keyword, results=results_html)
     else:
            results = "No relevant sections found."

    #     section = ""

    #     output = ""
    #     for filename, sections in results.items():
    #         #   results = f"\n--- {filename} ---\n"
    #         #for section in sections:
    #            doc = docx.Document(filename)
    #            parsed_html = parse_paragraphs(doc.paragraphs)
    #            return render_template('results.html', keyword=keyword, parsed_html=parsed_html)
    #  else:
    #      results = "No relevant sections found."

     return results

if __name__ == "__main__":
    # app.run(debug=True)
    app.run(debug=True, host='127.0.0.1', port=8081)
