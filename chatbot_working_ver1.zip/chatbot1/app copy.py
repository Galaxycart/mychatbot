from flask import Flask, request, jsonify, render_template
from docx import Document
#from search_keyword import search_keyword
#from document_loader import load_documents
import os

app = Flask(__name__)

# Directory where the Word documents are stored
DOCS_DIR = 'documents'

def search_keyword_in_doc(doc_path, keyword):
    document = Document(doc_path)
    results = []

    for para in document.paragraphs:
        if keyword.lower() in para.text.lower():
            results.append(para.text)

    # Optionally handle tables, images, etc.
    # ...

    return results
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/search', methods=['POST'])
def search():
    data = request.get_json()
    keyword = data.get('keyword')

    if not keyword:
        return jsonify({'error': 'Keyword is required'}), 400

    results = {}
    for filename in os.listdir(DOCS_DIR):
        if filename.endswith('.docx'):
            file_path = os.path.join(DOCS_DIR, filename)
            matches = search_keyword_in_doc(file_path, keyword)
            if matches:
                results[filename] = matches

    return jsonify(results)

if __name__ == '__main__':
    app.run(debug=True)
