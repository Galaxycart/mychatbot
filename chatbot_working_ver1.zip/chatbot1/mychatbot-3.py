from flask import Flask, request, render_template, jsonify
#from your_module import search_keyword_in_documents  # Import your search function
import os
import nltk
import pdfplumber
import docx
from docx import Document
from nltk.tokenize import sent_tokenize
from PyPDF2 import PdfFileReader
import spacy
from nltk.tokenize import BlanklineTokenizer
from jinja2 import Template
import re

app = Flask(__name__)

# Ensure NLTK data is downloaded
nltk.download('punkt')

def extract_text_from_pdf(pdf_path):
    text = ""
    with pdfplumber.open(pdf_path) as pdf:
        for page in pdf.pages:
            text += page.extract_text()
    return text

def extract_text_from_docx(docx_path):
    doc = docx.Document(docx_path)
    text = "\n".join([para.text for para in doc.paragraphs])
    return text

def extract_text_from_txt(txt_path):
    with open(txt_path, 'r') as file:
        text = file.read()
    return text

def extract_text_from_file(file_path):
    if file_path.endswith('.pdf'):
        return extract_text_from_pdf(file_path)
    elif file_path.endswith('.docx'):
        return extract_text_from_docx(file_path)
    elif file_path.endswith('.txt'):
        return extract_text_from_txt(file_path)
    else:
        raise ValueError(f"Unsupported file type: {file_path}")

def search_keyword_in_text(keyword, text):
    sentences = nltk.sent_tokenize(text)
    relevant_sections = [sentence for sentence in sentences if keyword.lower() in sentence.lower()]
    return relevant_sections

def search_keyword_in_documents(keyword, directory):
    results = {}
    for filename in os.listdir(directory):
        file_path = os.path.join(directory, filename)
        try:
            text = extract_text_from_file(file_path)
            relevant_sections = search_keyword_in_text(keyword, text)
            if relevant_sections:
                results[filename] = relevant_sections
        except Exception as e:
            print(f"Error processing {filename}: {e}")
    return results


@app.route('/')
def index():
    return render_template('index.html')

@app.route('/search', methods=['POST'])
def search():
    # print("Welcome to the Document Search Chatbot!")
    # directory = input("Please enter the directory containing your documents: ")
    directory = 'documents'
    while True:
        keyword = request.form['keyword'].lower().strip()
        if keyword.lower() == 'exit':
            return "Goodbye!"
            # print("Goodbye!")
            # break
        results = search_keyword_in_documents(keyword, directory)

        if results:
            for filename, sections in results.items():
                # print(f"\n--- {filename} ---")
                for section in sections:
                    return render_template('results_w1.html', keyword=keyword, results=section)
                    # print(section)
                    # print("-" * 50)
        else:
            print("No relevant sections found.")

if __name__ == "__main__":
    app.run(debug=True)
    # app.run(debug=True, host='127.0.0.1', port=8081)