from flask import Flask, render_template, request
import os
import re
import docx
import nltk

# Ensure NLTK data is downloaded
nltk.download('punkt')

app = Flask(__name__)

# Text extraction function for DOCX
def extract_text_from_docx(docx_path):
    doc = docx.Document(docx_path)
    paragraphs = [para.text for para in doc.paragraphs]
    return paragraphs

# Keyword search function
def search_keyword_in_paragraphs(keyword, paragraphs):
    relevant_sections = []
    for para in paragraphs:
        if keyword.lower() in para.lower():
            relevant_sections.append(para)
    return relevant_sections

def search_keyword_in_documents(keyword, directory):
    results = {}
    for filename in os.listdir(directory):
        if filename.endswith('.docx'):
            file_path = os.path.join(directory, filename)
            try:
                paragraphs = extract_text_from_docx(file_path)
                relevant_sections = search_keyword_in_paragraphs(keyword, paragraphs)
                if relevant_sections:
                    results[filename] = relevant_sections
            except Exception as e:
                print(f"Error processing {filename}: {e}")
    return results

@app.route('/', methods=['GET', 'POST'])
def index():
   return render_template('index.html')

@app.route('/search', methods=['POST'])
def search():
    directory = 'documents'

    if request.method == 'POST':
        keyword = request.form['keyword'].lower().strip()
        results = search_keyword_in_documents(keyword, 'documents')
        return render_template('results_w1.html', keyword=keyword, results=results)
    return render_template('index.html')

if __name__ == "__main__":
    app.run(debug=True)
