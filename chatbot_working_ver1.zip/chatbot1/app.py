from flask import Flask, request, jsonify, render_template
from docx import Document
#from search_keyword import search_keyword
#from document_loader import load_documents
import os
import re
import nltk
import pdfplumber
from nltk.tokenize import sent_tokenize
from PyPDF2 import PdfFileReader


app = Flask(__name__)

# Directory where the Word documents are stored
DOCS_DIR = 'documents'

# Ensure NLTK data is downloaded
nltk.download('punkt')

def extract_text_from_pdf(pdf_path):
    text = ""
    with pdfplumber.open(pdf_path) as pdf:
        for page in pdf.pages:
            text += page.extract_text()
    return text

def extract_text_from_docx(docx_path):
    doc = docx.Document(docx_path)
    text = "\n".join([para.text for para in doc.paragraphs])
    return text

def extract_text_from_txt(txt_path):
    with open(txt_path, 'r') as file:
        text = file.read()
    return text

def extract_text_from_file(file_path):
    if file_path.endswith('.pdf'):
        return extract_text_from_pdf(file_path)
    elif file_path.endswith('.docx'):
        return extract_text_from_docx(file_path)
    elif file_path.endswith('.txt'):
        return extract_text_from_txt(file_path)
    else:
        raise ValueError(f"Unsupported file type: {file_path}")

def search_keyword_in_text(keyword, text):
    sentences = nltk.sent_tokenize(text)
    relevant_sections = [sentence for sentence in sentences if keyword.lower() in sentence.lower()]
    return relevant_sections

# def search_keyword_in_documents(keyword, directory):
#     results = {}
#     for filename in os.listdir(directory):
#         file_path = os.path.join(directory, filename)
#         try:
#             text = extract_text_from_file(file_path)
#             relevant_sections = search_keyword_in_text(keyword, text)
#             if relevant_sections:
#                 results[filename] = relevant_sections
#         except Exception as e:
#             print(f"Error processing {filename}: {e}")
#     return results


def search_keyword_in_doc(doc_path, keyword):
    document = Document(doc_path)
    results = []

    for para in document.paragraphs:
        if keyword.lower() in para.text.lower():
            results.append(para.text)

    # Optionally handle tables, images, etc.
    # ...

    return results
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/search', methods=['POST'])
def search():
    data = request.get_json()
    keyword = data.get('keyword')

    if not keyword:
        return jsonify({'error': 'Keyword is required'}), 400


    results = {}
    for filename in os.listdir(DOCS_DIR):
        if filename.endswith('.docx'):
            file_path = os.path.join(DOCS_DIR, filename)
            matches = search_keyword_in_doc(file_path, keyword)
            if matches:
                results[filename] = matches

    return jsonify(results)
    # results = search_keyword_in_documents(keyword, directory)
    # if results:
    #         for filename, sections in results.items():
    #             print(f"\n--- {filename} ---")
    #             for section in sections:
    #                 print(section)
    #                 print("-" * 50)
    #        return jsonify(results)
    # else:
    #         print("No relevant sections found.")

    # results = {}
    # for filename in os.listdir(DOCS_DIR):
    #     if filename.endswith('.docx'):
    #         file_path = os.path.join(DOCS_DIR, filename)
    #         matches = search_keyword_in_doc(file_path, keyword)
    #         if matches:
    #             results[filename] = matches



if __name__ == '__main__':
    app.run(debug=True)
