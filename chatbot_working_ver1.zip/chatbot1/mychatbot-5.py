from flask import Flask, render_template, request
import os
import re
import docx
import nltk

# Ensure NLTK data is downloaded
nltk.download('punkt')

app = Flask(__name__)

# Text extraction function for DOCX
def extract_text_from_docx(docx_path):
    doc = docx.Document(docx_path)
    text = "\n".join([para.text for para in doc.paragraphs])
    return text

def extract_text_from_file(file_path):
    if file_path.endswith('.docx'):
     return extract_text_from_docx(file_path)
    else:
        raise ValueError(f"Unsupported file type: {file_path}")
    
# Keyword search function

def search_keyword_in_text(keyword, text):
    sentences = nltk.sent_tokenize(text)
    relevant_sections = [sentence for sentence in sentences if keyword.lower() in sentence.lower()]
    return relevant_sections

# def search_keyword_in_paragraphs(keyword, paragraphs):
#     relevant_sections = []
#     for para in paragraphs:
#         if keyword.lower() in para.lower():
#             relevant_sections.append(para)
#     return relevant_sections

def search_keyword_in_documents(keyword, directory):
    results = {}
    for filename in os.listdir(directory):
    #    if file_path.endswith('.docx'):
        file_path = os.path.join(directory, filename)
        try:
            text = extract_text_from_docx(file_path)
            relevant_sections = search_keyword_in_text(keyword, text)
            if relevant_sections:
                results[filename] = relevant_sections
        except Exception as e:
            print(f"Error processing {filename}: {e}")
    return results


# Keyword search function
# def search_keyword_in_paragraphs(keyword, paragraphs):
#     relevant_sections = []
#     for para in paragraphs:
#         if keyword.lower() in para.lower():
#             relevant_sections.append(para)
#     return relevant_sections

# def search_keyword_in_documents(keyword, directory):
#     results = {}
#     for filename in os.listdir(directory):
#         if filename.endswith('.docx'):
#             file_path = os.path.join(directory, filename)
#             try:
#                 paragraphs = extract_text_from_docx(file_path)
#                 relevant_sections = search_keyword_in_documents(keyword, text)
#                 if relevant_sections:
#                     results[filename] = relevant_sections
#             except Exception as e:
#                 print(f"Error processing {filename}: {e}")
#     return results

@app.route('/', methods=['GET', 'POST'])
def index():
   return render_template('index.html')

@app.route('/search', methods=['POST'])
def search():
    directory = 'documents'
    while True:
    #  if request.method == 'POST':
     keyword = request.form['keyword'].lower().strip()
     results = search_keyword_in_documents(keyword, directory)
     if results:
        for filename, sections in results.items():
            for section in sections:
        #     for section in sections:
              return render_template('results_w1.html', keyword=keyword, results=results)
     return render_template('index.html')

if __name__ == "__main__":
    app.run(debug=True)
