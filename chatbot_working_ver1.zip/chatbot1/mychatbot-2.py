from flask import Flask, request, render_template, jsonify
import os
import re
import nltk
import pdfplumber
import docx
from PyPDF2 import PdfFileReader

app = Flask(__name__)
# Ensure NLTK data is downloaded
nltk.download('punkt')

def extract_text_from_pdf(pdf_path):
    text = ""
    with pdfplumber.open(pdf_path) as pdf:
        for page in pdf.pages:
            text += page.extract_text()
    return text

def extract_text_from_docx(docx_path):
    doc = docx.Document(docx_path)
    text = "\n".join([para.text for para in doc.paragraphs])
    return text

def extract_text_from_txt(txt_path):
    with open(txt_path, 'r') as file:
        text = file.read()
    return text

def extract_text_from_file(file_path):
    if file_path.endswith('.pdf'):
        return extract_text_from_pdf(file_path)
    elif file_path.endswith('.docx'):
        return extract_text_from_docx(file_path)
    elif file_path.endswith('.txt'):
        return extract_text_from_txt(file_path)
    else:
        raise ValueError(f"Unsupported file type: {file_path}")

def parse_paragraphs(paragraphs):
    parsed_html = []
    for para in paragraphs:
        parsed_html.append(f'<p>{para.text}</p>')
    return '\n'.join(parsed_html)

def search_keyword_in_text(keyword, text):
    sentences = nltk.sent_tokenize(text)
    relevant_sections = [sentence for sentence in sentences if keyword.lower() in sentence.lower()]
    return relevant_sections

def search_keyword_in_documents(keyword, directory):
    results = {}
    for filename in os.listdir(directory):
       if filename.endswith('.docx'):
          file_path = os.path.join(directory, filename)
       try:
            text = extract_text_from_file(file_path)
            relevant_sections = search_keyword_in_text(keyword, text)
            if relevant_sections:
                results[filename] = relevant_sections
       except Exception as e:
            print(f"Error processing {filename}: {e}")
    return results



@app.route('/')
def index():
    return render_template('index.html')

@app.route('/search', methods=['POST'])


def search():
    # print("Welcome to the Document Search Chatbot!")
    # directory = input("Please enter the directory containing your documents: ")
    directory = 'documents'

    while True:
        keyword = request.form['keyword'].lower().strip()

        if keyword.lower() == 'exit':
            return "Goodbye!"
            
        results = search_keyword_in_documents(keyword, directory)

        if results:
            results_html = []
            for result in results:
                # filename = result['filename']
                # content = result['content']
                # file_path = os.path.join(directory, filename)
                # doc = docx.Document(file_path )
                # parsed_html = parse_paragraphs(doc.paragraphs)
                parsed_html = results_html.append(f"<h3><p>{results}</p></h3>")

                # for filename, sections in results.items():
                #     # print(f"\n--- {filename} ---")
                #     for section in sections:
                #         # print(section)
                #         # print("-" * 50)
                #         results_html.append(f"<h3><p>{section}</p></h3>")
            return render_template('results.html', keyword=keyword, results=results_html)
        else:
            return "No relevant sections found."

if __name__ == "__main__":
    # chatbot()
  app.run(debug=True, host='127.0.0.1', port=5000)