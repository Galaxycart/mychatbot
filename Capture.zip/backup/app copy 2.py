from flask import Flask, request, render_template, jsonify
#from your_module import search_keyword_in_documents  # Import your search function
import os
import nltk
import pdfplumber
import docx
from docx import Document
from nltk.tokenize import sent_tokenize
from PyPDF2 import PdfFileReader
import spacy
from nltk.tokenize import BlanklineTokenizer
from jinja2 import Template
import re

app = Flask(__name__)
nltk.download('punkt')

def extract_text_from_pdf(pdf_path):
    text = ""
    with pdfplumber.open(pdf_path) as pdf:
        for page in pdf.pages:
            text += page.extract_text()
    return text

def extract_text_from_docx(docx_path):
    doc = docx.Document(docx_path)
    text = "\n".join([para.text for para in doc.paragraphs])
    # text = ([para.text for para in doc.paragraphs])
    return text

def extract_text_from_txt(txt_path):
    with open(txt_path, 'r') as file:
        text = file.read()
    return text

def extract_text_from_file(file_path):
    if file_path.endswith('.pdf'):
        return extract_text_from_pdf(file_path)
    elif file_path.endswith('.docx'):
        return extract_text_from_docx(file_path)
    elif file_path.endswith('.txt'):
        return extract_text_from_txt(file_path)
    else:
        raise ValueError(f"Unsupported file type: {file_path}")


def split_into_paragraphs(text):
    # Split text by double newlines and also by indents to catch more paragraph variations
    # return re.split(r'\n\s*\n|\n\t|\n {4}', text.strip())
    #return re.split('\.\s|\n\n', text.strip())
    return re.split('\.\s|\n\n|\r|\f|\b {4}', text.strip())

def search_keyword_in_text(keyword, text):
    paragraphs = split_into_paragraphs(text)  # Use the enhanced paragraph splitting function
    # relevant_sections = []

    # for paragraph in paragraphs:
    #     sentences = nltk.sent_tokenize(paragraph)
    #     for sentence in sentences:
    #         if keyword.lower() in sentence.lower():
    #             # Highlight keyword in the paragraph for better readability
    #             highlighted_paragraph = re.sub(f'({keyword})', r'\033[1;31m\1\033[0m', paragraph, flags=re.I)
    #             relevant_sections.append(highlighted_paragraph)
    #             break  # If one sentence in the paragraph contains the keyword, add the whole paragraph and stop checking further sentences in this paragraph.
    #     return relevant_sections



# def search_keyword_in_text(keyword, text):
#     # sentences = nltk.sent_tokenize(text)
#     # # relevant_sections = [sentence for sentence in sentences if keyword.lower() in sentence.lower()]
#     # paragraphs = text.split("\n\n")  # Assuming paragraphs are separated by double newlines
#     # relevant_sections = [para for para in paragraphs if keyword.lower() in para.lower()]

#     # # text = nltk.corpus.brown.raw()[:1000]
#     # paras = BlanklineTokenizer().tokenize(text)
#     # doc = spacy.load(text)
#     # sentences = doc.sents
    # paragraphs = text.split("\n\n")  # Assuming paragraphs are separated by double newlines
    relevant_sections = []

    for paragraph in paragraphs:
        sentences = nltk.sent_tokenize(paragraph)
        for sentence in sentences:
            if keyword.lower() in sentence.lower():
                relevant_sections.append(paragraph)
                break  # If one sentence in the paragraph contains the keyword, add the whole paragraph and stop checking further sentences in this paragraph.
    return relevant_sections


def search_keyword_in_documents(keyword, directory):
    results = {}
    for filename in os.listdir(directory):
        file_path = os.path.join(directory, filename)
        try:
            text = extract_text_from_file(file_path)
            relevant_sections = search_keyword_in_text(keyword, text)
            if relevant_sections:
                results[filename] = relevant_sections
        except Exception as e:
            print(f"Error processing {filename}: {e}")
    return results

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/search', methods=['POST'])

def search():
    directory = 'documents'

    while True:
     keyword = request.form['keyword'].lower()

     if keyword.lower() == 'exit':
        return "Goodbye!"
         
     results = search_keyword_in_documents(keyword, directory)
  
     if results:
        section = ""

        # output = ""
        for filename, sections in results.items():
            #   results = f"\n--- {filename} ---\n"
            for section in sections:
               return render_template('results.html', keyword=keyword, results=results)
            #    template = Template('results.html')
            #    results = template.render(section=section)
                # nresults = print(section)
        #         template = Template('results.html')
        #         render_html =template.render(section=section)
        #         print(render_html)
            #  return render_template('results.html', keyword=keyword, results=results)
            #    return render_template('results.html', keyword=keyword, results=results)
         
     else:
         results = "No relevant sections found."

     return results
# def search():
#     keyword = request.form['keyword']
#     directory = 'documents'
#     results = search_keyword_in_documents(keyword, directory)

#     if results:
#         for filename, sections in results.items():
#             # return render_template('results.html', keyword=keyword, results=results)
#             for section in sections:
#                 return render_template('results.html', keyword=keyword,results=results)


if __name__ == "__main__":
    app.run(debug=True)
